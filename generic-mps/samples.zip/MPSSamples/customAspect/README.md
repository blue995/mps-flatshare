﻿Custom aspects

==============


This sample illustrates definition of custom language definition aspects.
