The Simplest Language
=====================

A minimalistic example of a language definition and its use.
The structure of the language defines a single rootable concept with a single string property.
The editor defines a straightforward notation for the concept.
The generator creates a Java class with a public static void main method to run the generated code and print the value of the property to the standard output of the program.

Check out a tutorial at https://www.jetbrains.com/help/mps/fast-track-to-mps.html to learn the fundamentals of MPS before you continue exploring the other samples.
